<p align="center">$${\color{green}ESTE \space WEBSITE \space NÃO \space APRESENTA \space NENHUM \space RISCO \space DE \space BLOQUEIAR \space SUA \space CONTA \space DO \space CMSP}$$</p>

---

<a href="#"><img width="100%" src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&duration=1&pause=1000&color=0d1117&center=true&vCenter=true&repeat=false&width=435&height=30&lines=CMSP+Tareafas"/>
<a href="#"><img width="100%" src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&duration=1&pause=1000&color=FFFFFF&center=true&vCenter=true&repeat=false&width=435&height=30&lines=CMSP+Tareafas"/>

<div align="center">
  <a href="https://darkmod3.github.io/CMSPKiller/" target="_blank"><img src="https://img.shields.io/badge/-CMSP Killer-4169e1?style=for-the-badge&logo=htmx&logoColor=white"></a>
</div>

<br>

---

<p align="center">Website para realizar automaticamente as tarefas do CMSP (novas e expiradas). Para utilizá-lo, basta clicar no botão acima e seguir as instruções que estão lá!</p>
