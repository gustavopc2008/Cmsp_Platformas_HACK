<a href="#"><img width="100%" src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&duration=1&pause=1000&color=0d1117&center=true&vCenter=true&repeat=false&width=435&height=30&lines=CMSP+Plataforma+Hacks"/>
<a href="#"><img width="100%" src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&duration=1&pause=1000&color=FFFFFF&center=true&vCenter=true&repeat=false&width=435&height=30&lines=CMSP+Plataforma+Hacks"/>

---

<p align="center"><strong>CMSP Plataforma Hacks</strong></p>
<p align="center">Neste repositório, você irá encontrar scripts/websites para automatizar as tarefas do CMSP e de outras plataformas como Khan Academy, Alura e Speak.</p>
<br><br>
<p align="center"><strong>Para começar a usar os scripts/websites, basta clicar no botão abaixo da plataforma que deseja utilizar</strong></p>

---

<p align="center">
    <a href="https://github.com/DarkMod3/CMSP-Plataformas-Hacks/blob/Main/CMSP.md"><img width="20%" alt="CMSP" title="CMSP" src="https://i.imgur.com/9RYlSj5.png"/></a>
    &#8287;&#8287;&#8287;&#8287;&#8287;
    <a href="https://github.com/DarkMod3/CMSP-Plataformas-Hacks/blob/Main/KhanAcademy.md"><img width="20%" alt="Khan Academy" title="Khan Academy" src="https://i.imgur.com/vOqofAR.png"/></a>
    &#8287;&#8287;&#8287;&#8287;&#8287;
    <a href="https://github.com/DarkMod3/CMSP-Plataformas-Hacks/blob/Main/SPeak.md"><img width="20%" alt="SPeak" title="SPeak" src="https://i.imgur.com/OzNkCvc.png"/></a>
    &#8287;&#8287;&#8287;&#8287;&#8287;
    <a href="https://github.com/DarkMod3/CMSP-Plataformas-Hacks/blob/Main/Alura.md"><img width="20%" alt="Alura" title="Alura" src="https://i.imgur.com/pAkb0hV.png"/></a>
    <br><br>
    <a href="#"><img src="https://komarev.com/ghpvc/?username=CMSP&style=for-the-badge&label=Views:&color=gray"/></a>
</p>

---
